create sequence productId_seq start with 100 increment by 1;
select * from PRODUCTDETAILS;
create table products1(PID NUMBER PRIMARY KEY,CATEGORY VARCHAR2(10),PNAME VARCHAR2(10),PRICE NUMBER(10),PQUANTITY NUMBER);
drop sequence productId_seq;